use classicmodels;

###total sales 
SELECT CONCAT('$',round(SUM(priceEach * quantityOrdered)/1000000,   2), 'M') AS total_sales
FROM orderdetails;

###total shipped orders
select sum(count_shipped_orders) as total_order_shipped from(
select count(ordernumber) as count_shipped_orders from orders where orders.status = "shipped") as d;

####sum of quantity that have been shipped
select sum(quantityordered) as total_quantity_shipped from orderdetails od
inner join orders o using(ordernumber)
where o.status = "shipped";
###Avg of quantity shipped
SELECT
  total_order_shipped,
  total_quantity_shipped,
  total_quantity_shipped / total_order_shipped AS average_quantity_per_order
FROM (
  -- Total Shipped Orders
  SELECT SUM(count_shipped_orders) AS total_order_shipped
  FROM (
    SELECT COUNT(ordernumber) AS count_shipped_orders
    FROM orders
    WHERE orders.status = "shipped"
  ) AS d
) AS total_orders,
(
  -- Sum of Quantity Shipped
  SELECT SUM(quantityordered) AS total_quantity_shipped
  FROM orderdetails od
  INNER JOIN orders o USING(ordernumber)
) AS total_quantity;

####total cancelled orders
select sum(count_cancelled_orders) as total_order_cancelled from(
select count(ordernumber) as count_cancelled_orders from orders where orders.status = "cancelled") as d;
 
###total quantities cancelled
select sum(quantityordered) as total_quantity_cancelled from orderdetails od
inner join orders o using(ordernumber)
where o.status = "cancelled";

##total quantities inprocess
select sum(quantityordered) as total_quantity_inprocess from orderdetails od
inner join orders o using(ordernumber)
where o.status = "In Process";

###total quantities on hold
select sum(quantityordered) as total_quantity_onhold from orderdetails od
inner join orders o using(ordernumber)
where o.status = "On Hold";

### total quantities resolved
select sum(quantityordered) as total_quantity_resolved from orderdetails od
inner join orders o using(ordernumber)
where o.status = "Resolved";

####sum of quantity ordered
select concat("",round(SUM(quantityOrdered)/1000,2),"K") from orderdetails;

###selling price 

select orderNumber, (quantityordered * priceEach) as sellingprice from orderdetails;

###cost price 
select (od.quantityordered * pd.buyprice) as costprice from orderdetails od
inner join products pd using(productcode) ;

SET SQL_SAFE_UPDATES = 0;
###total profit
alter table orderdetails
add column selling_price decimal(10,2);
 update orderdetails
 set selling_price = quantityordered * priceEachsellingpriceselling_price ;
 
 alter table orderdetails
 add column cost_price decimal(10,2);
 update orderdetails od
 JOIN products p using(productcode)
 set cost_price = od.quantityordered * p.buyprice;
 
 select concat('$' ,round(sum( selling_price - cost_price)/1000000,2),'M') as total_profit from orderdetails;
 
 
##total payment done by each customer

select sum(amount) , c.customerNumber from customers c
inner join payments p on c.customerNumber = p.customerNumber
group by customerNumber;

### TOTAL PAYMENT
select concat("$",round(sum(sum_payment)/1000000,2),"M") as total_amount  from
(
select sum(amount) as sum_payment , c.customerName from customers c
inner join payments p on c.customerNumber = p.customerNumber
group by customerName) as d;

#### Total number of customers
select count(customernumber) as total_customers from customers
where customernumber is not  null;


###total no of quantities in stock
select concat("",round(sum(quantityinstock)/1000 , 2),"K") from products;

####total employess
select count( distinct employeenumber) as total_employees from employees;

####which country has most employess
select max(country) most_employee_country from(
select count(employeenumber), country from employees e
inner join customers c on e.employeeNumber = c.salesRepEmployeeNumber
group by country) as d;

####which country has most customers
select max(country) as max_customer_country from (
select count(customernumber) , country from customers 
group by country ) as f;

#### which country has maximum quantity orders
select max(country) as max_quantityorder_country  from (
select count(quantityordered) quantity_ordered , country from orderdetails
inner join orders  using(ordernumber) inner join customers using(customernumber)
group by country) as g;

###payment done 
select  sum(amount) , e.firstname , e.lastName from employees e
join customers c on c.salesRepEmployeeNumber = e.employeeNumber
join payments p on c.customerNumber = p.customerNumber
group by e.firstname , e.lastName;

###total products
select count(distinct productcode)  as total_products from products;

##total profit by productname
select concat("",ROUND(sum(selling_price - cost_price)/1000,2),"K") as profit, productname 
from orderdetails od
inner join products p on od.productCode = p.productCode
group by productName;

delimiter //
create procedure getcustomerinfo(in customernumber int)
begin 
select contactFirstName,contactLastName, customernumber
from customers
where customernumber = customernumber;
end
//

####sales amount by orderdate
SELECT 
  o.orderDate, 
  od.priceEach * od.quantityOrdered AS sales_amount
FROM orders o
JOIN orderdetails od ON o.orderNumber = od.orderNumber
WHERE o.orderDate BETWEEN '2003-01-01' AND '2005-12-31' -- Filter by a specific time period
ORDER BY sales_amount DESC; -- Sort in descending order based on sales amount


CREATE VIEW orders_in_USA AS
SELECT o.orderNumber, c.customerName, o.orderDate,
       CONCAT('$', FORMAT(SUM(od.priceEach * od.quantityOrdered) / 1000000, 2), 'M') AS total_amount
FROM orders o
JOIN customers c ON o.customerNumber = c.customerNumber
JOIN orderdetails od ON o.orderNumber = od.orderNumber
WHERE c.country = 'USA'
GROUP BY o.orderNumber, c.customerName, o.orderDate;










